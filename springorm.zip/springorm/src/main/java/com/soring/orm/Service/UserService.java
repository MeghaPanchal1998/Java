package com.soring.orm.Service;

import com.soring.orm.Model.Login;
import com.soring.orm.Model.User;

public interface UserService {
	
	void register(User user);

	  User validateUser(Login login);

}
