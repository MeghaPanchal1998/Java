package com.spring.dependencyInjection.constinj;

public class Employee {
	
	private int empId;
	private String name;
	private String address;
	private Manager manager; // injecting the manager details
	
	public Employee(int empId, String name, String address, Manager manager) {
		
		this.empId = empId;
		this.name = name;
		this.address = address;
		this.manager = manager;
	}
	
	public void display() {
		
		System.out.println("EmpId : "+empId);
		System.out.println("Name : "+name);
		System.out.println("Address : "+address);
		System.out.println("Manager : "+manager);
	}
	
	
	

}
