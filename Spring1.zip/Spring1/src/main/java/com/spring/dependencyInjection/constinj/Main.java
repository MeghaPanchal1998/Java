package com.spring.dependencyInjection.constinj;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		String config_loc = "/com/spring/dependencyInjection/constinj/ConstConfig.xml";
		ApplicationContext context = new ClassPathXmlApplicationContext(config_loc);
		
		Employee emp = (Employee)context.getBean("empId");
		emp.display();

	}

}
