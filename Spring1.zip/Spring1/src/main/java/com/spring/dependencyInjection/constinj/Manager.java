package com.spring.dependencyInjection.constinj;

public class Manager {
	
	private int managerId;
	private String name;
	private String designation;
	
	public Manager(int managerId, String name, String designation) {
		
		this.managerId = managerId;
		this.name = name;
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "Manager [managerId=" + managerId + ", name=" + name + ", designation=" + designation + "]";
	}
	
	
	
	

}
