package com.assign;

import java.util.HashMap;
import java.util.Map;

public class CRUDOperations {
	private Map<Integer, Student> students;

	public CRUDOperations() {
		this.students = new HashMap<>();
	}

	// Create operation
	public void addStudent(Student student) {
		students.put(student.getStudentId(), student);
	}

	// Read operation
	public Student getStudent(int studentId) {
		return students.get(studentId);
	}

	// Update operation
	public void updateStudent(Student student) {
		if (students.containsKey(student.getStudentId())) {
			students.put(student.getStudentId(), student);
		} else {
			System.out.println("Student not found, cannot update.");
		}
	}

	// Delete operation
	public void deleteStudent(int studentId) {
		students.remove(studentId);
	}

	// Print all students
	public void printAllStudents() {
		for (Student student : students.values()) {
			System.out.println("Student ID: " + student.getStudentId());
			System.out.println("Student Name: " + student.getStudentName());
			Address address = student.getAddress();
			System.out.println("Address ID: " + address.getAddressId());
			System.out.println("Street: " + address.getStreet());
			System.out.println("City: " + address.getCity());
			System.out.println("State: " + address.getState());
			System.out.println("Zip Code: " + address.getZipCode());
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Address address1 = new Address(1, "123 Main St", "Springfield", "IL", "62701");
        Student student1 = new Student(1, "John Doe", address1);

        CRUDOperations crud = new CRUDOperations();
        crud.addStudent(student1);

        System.out.println("All Students:");
        crud.printAllStudents();

        // Update example
        student1.setStudentName("Jane Doe");
        crud.updateStudent(student1);

        System.out.println("After Update:");
        crud.printAllStudents();

        // Delete example
        crud.deleteStudent(1);

        System.out.println("After Delete:");
        crud.printAllStudents();
    }
	}


