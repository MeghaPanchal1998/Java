package com.demo;

import java.util.HashSet;
import java.util.Set;

public class Cart {
	 private int cartId;
	    private double total;
	    private String name;
	    private Set<Item> items = new HashSet<>();

	    // Constructor, getters, and setters
	    public Cart(int cartId, double total, String name) {
	        this.cartId = cartId;
	        this.total = total;
	        this.name = name;
	    }

	    public int getCartId() {
	        return cartId;
	    }

	    public void setCartId(int cartId) {
	        this.cartId = cartId;
	    }

	    public double getTotal() {
	        return total;
	    }

	    public void setTotal(double total) {
	        this.total = total;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public Set<Item> getItems() {
	        return items;
	    }

	    public void setItems(Set<Item> items) {
	        this.items = items;
	    }

	    // Utility method to add an item to the cart
	    public void addItem(Item item) {
	        items.add(item);
	        item.setCart(this);
	    }

	    // Utility method to remove an item from the cart
	    public void removeItem(Item item) {
	        items.remove(item);
	        item.setCart(null);
	    }

}
