package com.demo;

public class CRUDOneToManyManyToOneDemo {
	
	public static void main(String[] args) {
        // Create a cart
        Cart cart1 = new Cart(1, 0.0, "Shopping Cart");

        // Create items
        Item item1 = new Item(101, "item101", 25.0, 2);
        Item item2 = new Item(102, "item102", 50.0, 1);

        // Establish relationships
        cart1.addItem(item1);
        cart1.addItem(item2);

        // Print cart details with items
        System.out.println("Cart ID: " + cart1.getCartId());
        System.out.println("Cart Name: " + cart1.getName());
        System.out.println("Total: $" + cart1.getTotal());
        System.out.println("Items:");

        for (Item item : cart1.getItems()) {
            System.out.println("Item ID: " + item.getId());
            System.out.println("Item Name: " + item.getItemId());
            System.out.println("Quantity: " + item.getQuantity());
            System.out.println("Item Total: $" + item.getItemTotal());
            System.out.println();
        }

        // Update item quantity
        item1.setQuantity(3);
        item1.setItemTotal(item1.getItemTotal() * item1.getQuantity());

        // Remove an item from the cart
        cart1.removeItem(item2);

        // Print updated cart details
        System.out.println("\nUpdated Cart Details:");
        System.out.println("Cart ID: " + cart1.getCartId());
        System.out.println("Cart Name: " + cart1.getName());
        System.out.println("Total: $" + cart1.getTotal());
        System.out.println("Items:");

        for (Item item : cart1.getItems()) {
            System.out.println("Item ID: " + item.getId());
            System.out.println("Item Name: " + item.getItemId());
            System.out.println("Quantity: " + item.getQuantity());
            System.out.println("Item Total: $" + item.getItemTotal());
            System.out.println();
        }
    }

}
