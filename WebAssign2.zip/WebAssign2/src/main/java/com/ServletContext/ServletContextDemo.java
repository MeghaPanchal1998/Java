package com.ServletContext;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/myservlet")
public class ServletContextDemo extends HttpServlet {

	 private static final long serialVersionUID = 1L;

	    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
	            throws ServletException, IOException {
	        response.setContentType("text/html");

	        // Get ServletContext
	        ServletContext context = getServletContext();

	        // Retrieve initialization parameter from ServletContext
	        String adminEmail = context.getInitParameter("adminEmail");

	        // Generate HTML response
	        PrintWriter out = response.getWriter();
	        out.println("<html><body>");
	        out.println("<h2>Servlet Context Example</h2>");
	        out.println("<p>Admin Email: " + adminEmail + "</p>");
	        out.println("</body></html>");
	    }
}
