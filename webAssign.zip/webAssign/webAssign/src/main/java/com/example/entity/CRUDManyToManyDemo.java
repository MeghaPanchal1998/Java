package com.example.entity;

public class CRUDManyToManyDemo {

	public static void main(String[] args) {
		 // Create readers
        Reader reader1 = new Reader(1, "john.doe@example.com", "John", "Doe");
        Reader reader2 = new Reader(2, "jane.smith@example.com", "Jane", "Smith");

        // Create subscriptions
        Subscription subscription1 = new Subscription(101, "Daily News");
        Subscription subscription2 = new Subscription(102, "Weekly Digest");

        // Establish relationships
        reader1.addSubscription(subscription1);
        reader1.addSubscription(subscription2);
        reader2.addSubscription(subscription2);

        // Perform CRUD operations
        // For simplicity, assume we have methods to manage CRUD operations
        // on Readers and Subscriptions

        // Print readers and their subscriptions
        System.out.println("Reader 1 Subscriptions:");
        for (Subscription subscription : reader1.getSubscriptions()) {
            System.out.println(subscription.getSubscriptionName());
        }

        System.out.println("\nReader 2 Subscriptions:");
        for (Subscription subscription : reader2.getSubscriptions()) {
            System.out.println(subscription.getSubscriptionName());
        }
    }

	}

}
