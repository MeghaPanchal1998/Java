package com.example.entity;

import java.util.HashSet;
import java.util.Set;




public class Subscription {

	private int subscriptionId;
    private String subscriptionName;
    private Set<Reader> readers = new HashSet<>();

    // Constructor, getters, and setters
    public Subscription(int subscriptionId, String subscriptionName) {
        this.subscriptionId = subscriptionId;
        this.subscriptionName = subscriptionName;
    }

    public int getSubscriptionId() {
        return subscriptionId;
    }

    public void setSubscriptionId(int subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    public String getSubscriptionName() {
        return subscriptionName;
    }

    public void setSubscriptionName(String subscriptionName) {
        this.subscriptionName = subscriptionName;
    }

    public Set<Reader> getReaders() {
        return readers;
    }

    public void setReaders(Set<Reader> readers) {
        this.readers = readers;
    }
}
